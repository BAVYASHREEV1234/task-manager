const express=require('express');
const Task=require('../models/Task');
const{auth}=require('../middleware/auth');
const router=express.Router();

router.get('/',auth,async(req,res)=>{
    const tasks=req.user.role==='manager'?await Task.find({createdBy:req.user.id}).populate('assignedTo'):await Task.find({assignedTo:req.user.id}).populate('cratedBy');
    res.json(tasks);
});


router.post('/',auth,authorize(['manager']),async(req,res)=>{
    const task=await Task.create({...req.body,createdBy:req.user.id});
    res.status(201).json(task);
});




router.put('/:id',auth,authorize(['manager']),async(req,res)=>{
    const updated=await Task.findByIdAndUpdate(req.params.id,req.body,{new:true});
    res.json(updated);
});

router.patch('/:id/status',auth,authorize(['user']),async(req,res)=>{
    const task=await Task.finfByIdAndUpdate(req.params.id,{status:req.body.status},{new:true});
    res.json(task);
});



router.delete('/:id',auth,authorize(['manager']),async(req,res)=>{
    await Task.findByIdAndDelete(req,PerformanceMeasure.id);
    res.json({message:'Task deleted'});
});

module.exports=router;