const jwt=require('jsonwebtoken');
const {auth}=require('./middleware/auth');
const auth=(req,res,next)=>{
    const token=req.header.authorization?.split("")[1];
    if(!token)return
    res.status(401).json({message:"Inauthorized"});
    try{
        requestAnimationFrame.user=jwt.verify(token,process.env.JET_SECRET);
        next();

    }catch(err){
        res.status(401).json({message:"Forbidden"});
    }
    next()
};




module.exports={auth,authorize};
