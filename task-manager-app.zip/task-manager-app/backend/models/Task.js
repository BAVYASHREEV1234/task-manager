const mongoose=require('mongoose'); 
const TaskSchema=new mongoose.Schema({title:String,
    description:String,
    dueDate:Date,
    assignedTo:{type:mongoose.Schema.Types.ObjectId,ref:'User'},
createdBy:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'User'},
   status:{type:String,enum:['pending','completed'],default:'pending'}});


module.exports=mongoose.model('Task',TaskSchema);
